package Instructions;
import java.io.PrintWriter;
import MIPS.RegFile;

import MIPS.ALU;
import MIPS.Processor;

public abstract class  Instruction implements Cloneable {
    private Instruction_Types inst_type;
	private String Opcode ;
	private Boolean IF ;
	private Boolean ID ;
	private int OutPutMEM;
	private boolean negativeNo;  
	private Boolean EX ;
	private Boolean MEM ;
	private Boolean WB ;	
	private  int instNum;
	private int startDecode ;
    private int startExecute ;
	private int rs ;
	private int rt ;
	private int rd ;
	private String rdString ;
	private String fetchedInst ;
	private String rsString;
	private String rtString;
	private int shamt ; 
	private int address;
	private int immediate;
	private int outPutALU ;
	private int MemorySavedNewData ;
	
	public Instruction(String Opcode,Instruction_Types inst_type) {
		this.inst_type = inst_type;
		this.Opcode = Opcode;
		this.IF= false;
		this.ID= false;
		this.negativeNo=false;
		this.EX= false;
		this.MEM= false;
		this.WB= false;


	}
	
	public int getMemorySavedNewData() {
		return MemorySavedNewData;
	}


	public void setMemorySavedNewData(int memorySavedNewData) {
		MemorySavedNewData = memorySavedNewData;
	}


	public void printTest() {
		PrintWriter pw = new PrintWriter (System.out);
		System.out.println("instruction :"+ instName(Opcode));
		pw.println("OperandA :"+rsString);
		if(this.IF==false && rsString !=null) {
			pw.println("OperandA Data :"+RegFile.getRegData(rsString));

		}

		pw.println("OperandB :"+rtString);
		if(this.IF==false && rtString !=null) {
			pw.println("OperandB Data :"+RegFile.getRegData(rtString));

		}

		pw.println("DestReg :"+rdString);
		pw.println("output ALU : "+outPutALU);
		pw.println("Output Memory :"+ OutPutMEM);
		pw.println("shamt :"+shamt);
		pw.println("immediate :"+ immediate);
		pw.println("address :"+address);
		pw.println("IF :"+IF);
		pw.println("ID :"+ID);
		pw.println("EX :"+EX);
		pw.println("MEM :"+MEM);
		pw.println("WB :"+WB);
		pw.println();
		pw.flush();
	}

	
	public int getOutPutMEM() {
		return OutPutMEM;
	}
	public int getInstNum() {
		return instNum;
	}


	public void setInstNum(int instNum) {
		this.instNum = instNum;
	}

	public void setOutPutMEM(int outPutMEM) {
		OutPutMEM = outPutMEM;
	}


	public String getRsString() {
		return rsString;
	}


	public void setRsString(String rsString) {
		this.rsString = rsString;
	}


	public String getRtString() {
		return rtString;
	}


	public void setRtString(String rtString) {
		this.rtString = rtString;
	}


	public String getFetchedInst() {
		return fetchedInst;
	}

	public void setFetchedInst(String fetchedInst) {
		this.fetchedInst = fetchedInst;
	}

	public String getRdString() {
		return rdString;
	}

	public void setRdString(String rdString) {
		this.rdString = rdString;
	}

	public int getRs() {
		return rs;
	}

	public void setRs(int rs) {
		this.rs = rs;
	}

	public int getRt() {
		return rt;
	}

	public void setRt(int rt) {
		this.rt = rt;
	}

	public int getRd() {
		return rd;
	}

	public void setRd(int rd) {
		this.rd = rd;
	}

	public int getShamt() {
		return shamt;
	}

	public void setShamt(int shamt) {
		this.shamt = shamt;
	}

	public int getAddress() {
		return address;
	}

	public void setAddress(int address) {
		this.address = address;
	}

	public int getImmediate() {
		return immediate;
	}

	public void setImmediate(int immediate) {
		this.immediate = immediate;
	}

	public int getOutPutALU() {
		return outPutALU;
	}

	public void setOutPutALU(int outPutALU) {
		this.outPutALU = outPutALU;
	}

	
	public int getStartDecode() {
		return startDecode;
	}

	public void setStartDecode(int startDecode) {
		this.startDecode = startDecode;
	}

	public int getStartExecute() {
		return startExecute;
	}

	public void setStartExecute(int startExecute) {
		this.startExecute = startExecute;
	}



	public Instruction_Types getInst_type() {
		return inst_type;
	}

	public void setInst_type(Instruction_Types inst_type) {
		this.inst_type = inst_type;
	}

	public String getOpcode() {
		return Opcode;
	}

	public void setOpcode(String opcode) {
		Opcode = opcode;
	}


	
	public Object clone() throws CloneNotSupportedException
	{
		return super.clone();
	}
	
	public abstract int Execute(int OperandA , int OperandB);

	public int Execute(int imm) {
		// TODO Auto-generated method stub
		return 0;
	}
    public Boolean getIF() {
		return IF;
	}


	public void setIF(Boolean iF) {
		IF = iF;
	}


	public Boolean getID() {
		return ID;
	}


	public void setID(Boolean iD) {
		ID = iD;
	}


	public Boolean getEX() {
		return EX;
	}


	public void setEX(Boolean eX) {
		EX = eX;
	}


	public Boolean getMEM() {
		return MEM;
	}


	public void setMEM(Boolean mEM) {
		MEM = mEM;
	}


	public Boolean getWB() {
		return WB;
	}


	public void setWB(Boolean wB) {
		WB = wB;
	}
	public static Instruction createInst(String opcode) {
		Instruction inst = null ;
		switch(opcode) {
		case "0000": inst = new ADD();break;
		case "0001": inst = new SUB();break;
		case "0010": inst = new MUL();break;
		case "0011": inst = new MOVI();break;
		case "0100": inst = new JEQ();break;
		case "0101": inst = new AND();break;
		case "0110": inst = new XORI();break;
		case "0111": inst = new JMP();break;
		case "1000": inst = new LSL();break;
		case "1001": inst = new LSR();break;
		case "1010": inst = new MOVR();break;
		case "1011": inst = new MOVM();break;
		}
		return inst ;
	}
	public static String instName(String opcode) {
		String inst = "";
		switch(opcode) {
		case "0000": inst = "ADD";break;
		case "0001": inst = "SUB";break;
		case "0010": inst = "MUL";break;
		case "0011": inst = "MOVI";break;
		case "0100": inst = "JEQ";break;
		case "0101": inst = "AND";break;
		case "0110": inst = "XORI";break;
		case "0111": inst = "JMP";break;
		case "1000": inst = "LSL";break;
		case "1001": inst = "LSR";break;
		case "1010": inst = "MOVR";break;
		case "1011": inst = "MOVM";break;
		}
		return inst ;
	}


	
	

}
