package Instructions;
import Instructions.Instruction_Types;

public class ADD extends Instruction {
	public ADD() {
		super("0000",Instruction_Types.R_type);
	}

	@Override
	public int Execute(int OperandA, int OperandB) {
		int result = OperandA +OperandB ;
		return result;		
	}

	

}
