package Instructions;

public class XORI extends Instruction {

	public XORI() {
		super("0110",Instruction_Types.I_type);
	}

	@Override
	public int Execute(int OperandA, int imm) {
        int result = OperandA^imm;
        return result;
	}
}
