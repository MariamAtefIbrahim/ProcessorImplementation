package Instructions;

public class MOVI extends Instruction{
	public MOVI() {
		super("0011",Instruction_Types.I_type);
	}

	@Override
	
	public int Execute( int imm) {
        int result =  imm;
        
        return result;
	}

	@Override
	public int Execute(int OperandA, int OperandB) {
		return 0;
	}
}
