package Instructions;

import MIPS.Processor;
import MIPS.ALU;

public class JMP extends Instruction {

	public JMP() {
		super("0111",Instruction_Types.J_type);
	}
	public int  Execute(int OperandA, int OperandB) {
		return 0;
		
	}
	public int  Execute(String address) {
		String pcNewData = "";
		int pcPrevData = Processor.getPc().getData();
		String pcPrevDataBinaryString = Integer.toBinaryString(pcPrevData);
		while(pcPrevDataBinaryString.length()<32) {
			pcPrevDataBinaryString = "0" +pcPrevDataBinaryString;
		}
		for(int i =0 ; i<5; i++) {
			pcNewData = pcNewData + pcPrevDataBinaryString.charAt(i);
		}
		while(address.length()<28) {
			address = "0"+address;
		}
		String finalresultString = pcNewData+address;
		return Integer.parseInt(finalresultString,2);
	}

}
