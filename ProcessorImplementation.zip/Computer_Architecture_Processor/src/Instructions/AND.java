package Instructions;

public class AND extends Instruction{
	public AND() {
		super("0101",Instruction_Types.R_type);
	}

	public int Execute(int OperandA, int OperandB) {
         int result = OperandA & OperandB;
		
		return result ;
	}

}
