package Instructions;

public class SUB extends Instruction{
	
	public SUB() {
		super("0001",Instruction_Types.R_type);
	}

	@Override
	public int Execute(int OperandA, int OperandB) {
		int result = OperandA - OperandB;
		return result;
		
	}

}
