package Instructions;

public class LSR extends Instruction {
	
	public LSR() {
		super("1001",Instruction_Types.R_type);
	}

	@Override
	
	public int Execute(int OperandA, int shamt) {
        int result =OperandA;
        for(int i = 0 ; i<shamt ; i++) {
        	result = result/2;
        }
  
        return result;
	}

}
