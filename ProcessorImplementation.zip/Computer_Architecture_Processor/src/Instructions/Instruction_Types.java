package Instructions;

public enum Instruction_Types {

  R_type , I_type , J_type

}
