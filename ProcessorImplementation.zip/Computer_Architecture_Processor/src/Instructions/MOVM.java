package Instructions;

public class MOVM extends Instruction{

	
	public MOVM() {
		super("1011",Instruction_Types.I_type);
	}
	
	public int Execute(int OperandA, int imm) {
        int result =  OperandA + imm;
  
        return result;
	}
}
