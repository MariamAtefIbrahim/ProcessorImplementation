package Instructions;

public class MUL extends Instruction{
	
	public MUL() {
		super("0010",Instruction_Types.R_type);
	}

	@Override
	public int Execute(int OperandA, int OperandB) {
         int result = OperandA * OperandB;
         return result;
	}

}
