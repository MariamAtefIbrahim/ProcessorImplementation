package Instructions;
import MIPS.ALU;
import MIPS.Processor;
import MIPS.RegFile;
import MIPS.Register;

public class JEQ extends Instruction {
	
	public JEQ() {
		super("0100",Instruction_Types.I_type);
	}
	public int  Execute(int OperandA, int OperandB) {

		return 0;
		
	}
	public int  Execute(int OperandA, int OperandB, int imm) {
		if(OperandA == OperandB) {
			return imm;
		}
		return 0;
		
		
	}
	

}
