package Instructions;
import MIPS.Memory;
import MIPS.Processor;
public class MOVR extends Instruction{
	
	public MOVR() {
		super("1010",Instruction_Types.I_type);
	}

	
	public int Execute(int OperandA, int imm) {
        int result =  OperandA + imm;
        System.out.println("r2 :"+OperandA);

 
        return result;
	}

}
