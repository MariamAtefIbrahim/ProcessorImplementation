package Data_Structure;

import java.util.LinkedList;
import java.util.Queue;

public class FixedSizeQueue<T> extends LinkedList<T> implements Queue<T> {
    private int maxSize;

    public FixedSizeQueue(int maxSize) {
        this.maxSize = maxSize;
    }

    @Override
    public boolean offer(T element) {
        if (size() >= maxSize) {
            poll(); // Remove the oldest element
        }
        return super.offer(element);
    }
}
