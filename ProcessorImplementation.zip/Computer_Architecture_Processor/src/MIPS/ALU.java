package MIPS;
import java.util.*;
import Instructions.*;
import MIPS.Register;
import MIPS.Memory;
import Instructions.Instruction;


public class ALU {
	
	public static int ALU(int operandA, int operandB, int operation, int imm , int shamt , int address) {
      int output = 0;
      Instruction inst =null ;
      switch(operation) {
      case 0 :inst = new ADD();
      output= inst.Execute(operandA, operandB);break;
      case 1 :inst = new SUB();
      output= inst.Execute(operandA, operandB);break;
      case 2 :inst = new MUL();
      output= inst.Execute(operandA, operandB);break;
      case 3 :inst = new MOVI();
      output= inst.Execute(imm);break;
      case 4 :inst = new JEQ();
             output=  ((JEQ)inst).Execute(operandA, operandB, imm);break;
      case 5 :inst = new AND();
      output= inst.Execute(operandA, operandB);break;
      case 6 :inst = new XORI();
      output=  inst.Execute(operandA, imm);break;
      case 7 :inst = new JMP();
             output = ((JMP)inst).Execute(Integer.toBinaryString(address));break;
      case 8 :inst = new LSL();
      output=  inst.Execute(operandA,shamt);break;
      case 9 :inst = new LSR();
      output=   inst.Execute(operandA, shamt);break;
      case 10 :inst = new MOVR();
      output=   inst.Execute(operandA, imm);break;
      case 11 :inst = new MOVM();
      output=   inst.Execute(operandA, imm);break;
      }
//      System.out.println("Operation = "+operation);
//      System.out.println("First Operand = "+operandA);
//      System.out.println("Second Operand = "+operandB);
//      System.out.println("Result = "+output);
//      System.out.println("Zero Flag = ");
      
      return output;
  }
  
 



}




