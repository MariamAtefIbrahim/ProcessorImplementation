package MIPS;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.Queue;
import Data_Structure.*;
import MIPS.*;
import Instructions.*;

public class PipeLine {
	
    private static Queue<Instruction> AccumlatorReg;
    private static boolean startPipelining;
    private static boolean endPipelining;
    private static Processor mips ;
    private static boolean fetchingInstFinished;
    private static int updatedInstNum;
    private static int instNum;
    private static boolean jmpFlag;
    private static int i =1;
    private static boolean thirdInstJMPFLAG ;
    private static boolean secInstJMPFLAG ;
    private static boolean firstInstJMPFLAG ;
    private static boolean updatetIENTERED;
    private static boolean AccEmpty;
    private static boolean thirdInstJMPFLAG2;
    private static int firstInstJEQFLAG;
    private static int secInstJEQFLAG;
    private static int thirdInstJEQFLAG;
    private static boolean countUpd;

    

    
    
    
    
    public PipeLine() {
    	this.startPipelining =false ;
    	this.endPipelining = false ; 
    	this.AccumlatorReg=   new LinkedList<>();
    	this.fetchingInstFinished =false;
    	this.instNum = 0;
    	this.updatedInstNum = mips.getMemory().getInstCount();
    	this.jmpFlag = false;
    	this.firstInstJMPFLAG=false;
    	this.secInstJMPFLAG = false;
    	this.thirdInstJMPFLAG=false;
    	this.thirdInstJMPFLAG2 =false;
    	this.firstInstJEQFLAG =0;
    	this.secInstJEQFLAG=0;
    	this.thirdInstJEQFLAG=0;
    	this.countUpd=false;
    	
   
    		
    }
    	
        public static  void pipeline() {
    	if (startPipelining == false ) {
            System.out.println("PC :"+mips.getPc().getData());
    		Instruction firstInst = mips.Fetch();
    		startPipelining=true;
    		AccumlatorReg.add(firstInst);
    		while(endPipelining ==false )  {
    			if(countUpd) {
    				System.out.println("-------------------------------------------------------------");
        			System.out.println("CLOCK CYCLE : "+(i-1));
        			System.out.println();
    			}
    			else {
    				System.out.println("-------------------------------------------------------------");
        			System.out.println("CLOCK CYCLE : "+i);
        			System.out.println();
    			}
    			

    			if(jmpFlag == true) {
    				updatedInstNum = mips.getMemory().getInstCount()-(mips.getPc().getData()+1);
    				jmpFlag =false;
    			}
    			

    			if(mips.getMemory().getInstCount()==1 ||updatedInstNum ==1) {
    				if(updatedInstNum ==1) {
    					mips.getPc().setData(mips.getPc().getData()+1);
    					firstInst = mips.Fetch();
        				System.out.println("updatedInstNum :"+updatedInstNum);

    				}
    				firstInst.setIF(true);
    				instNum ++; 
            		firstInst.setInstNum(instNum);
    				System.out.println("Instruction : "+firstInst.getInstNum());
            		firstInst.printTest();
            		System.out.println();
		
    				mips.Decode(firstInst);
    				firstInst.setStartDecode(1);
    				firstInst.setID(true);
    				firstInst.setIF(false);
        			System.out.println("-------------------------------------------------------------");
                    i++;
    				System.out.println("CLOCK CYCLE : "+ i);
    				System.out.println("Instruction : "+firstInst.getInstNum());
            		firstInst.printTest();
            		System.out.println();

            		firstInst.setStartDecode(2);
        			System.out.println("-------------------------------------------------------------");

        			i++;

    				System.out.println("CLOCK CYCLE : "+ i);
    				System.out.println("Instruction : "+firstInst.getInstNum());
            		firstInst.printTest();
            		System.out.println();    				
 
            		
            		mips.Execute(firstInst);
            		firstInst.setEX(true);
            		firstInst.setID(false);
            		firstInst.setStartExecute(1);
        			System.out.println("-------------------------------------------------------------");
                    i++;

    				System.out.println("CLOCK CYCLE : "+ i);
    				System.out.println("Instruction : "+firstInst.getInstNum());
            		firstInst.printTest();
            		System.out.println();
            		
            		
            		firstInst.setStartExecute(2);
        			System.out.println("-------------------------------------------------------------");
                    i++;

    				System.out.println("CLOCK CYCLE : "+ i);
    				System.out.println("Instruction : "+firstInst.getInstNum());
            		firstInst.printTest();
            		System.out.println();

            		
            		
            		System.out.println("-------------------------------------------------------------");
                    i++;

    				System.out.println("CLOCK CYCLE : "+ i);
    				System.out.println("Instruction : "+firstInst.getInstNum());

    				mips.Memory(firstInst);
    				firstInst.setMEM(true);
            		firstInst.setEX(false);
        		
            		firstInst.printTest();
            		System.out.println();
            		
            		
            		System.out.println("-------------------------------------------------------------");
                    i++;

    				System.out.println("CLOCK CYCLE : "+ i);
    				System.out.println("Instruction : "+firstInst.getInstNum());
    				mips.WriteBack(firstInst);
    				firstInst.setWB(true);
            		firstInst.setMEM(false);
        			
            		firstInst.printTest();
            		System.out.println();
    				break;
    				
    			}
    		 if(mips.getMemory().getInstCount()==2) {
    			firstInst.setIF(true);
				instNum ++; 
        		firstInst.setInstNum(instNum);
				System.out.println("Instruction : "+firstInst.getInstNum());
        		firstInst.printTest();
        		System.out.println();
	
				mips.Decode(firstInst);
				firstInst.setStartDecode(1);
				firstInst.setID(true);
				firstInst.setIF(false);
                i++;

    			System.out.println("-------------------------------------------------------------");
				System.out.println("CLOCK CYCLE : "+ i);
				System.out.println("Instruction : "+firstInst.getInstNum());
        		firstInst.printTest();
        		System.out.println();

        		firstInst.setStartDecode(2);
        		Instruction secInst = mips.Fetch();
        		instNum++;
        		secInst.setInstNum(instNum);
        		secInst.setIF(true);
    			System.out.println("-------------------------------------------------------------");
                i++;

				System.out.println("CLOCK CYCLE : "+ i);
				System.out.println("Instruction : "+firstInst.getInstNum());
        		firstInst.printTest();
        		System.out.println();    	
        		System.out.println("Instruction : "+secInst.getInstNum());
        		secInst.printTest();
        		System.out.println(); 

        		
        		mips.Execute(firstInst);
        		firstInst.setEX(true);
        		firstInst.setID(false);
        		firstInst.setStartExecute(1);
        		mips.Decode(secInst);
        		secInst.setID(true);
        		secInst.setIF(false);
        		secInst.setStartDecode(1);
    			System.out.println("-------------------------------------------------------------");
                i++;

				System.out.println("CLOCK CYCLE : "+ i);
				System.out.println("Instruction : "+firstInst.getInstNum());
        		firstInst.printTest();
        		System.out.println();
        		System.out.println("Instruction : "+secInst.getInstNum());
        		secInst.printTest();
        		System.out.println();
        		
        		
        		firstInst.setStartExecute(2);
        		secInst.setStartDecode(2);
    			System.out.println("-------------------------------------------------------------");
                i++;

				System.out.println("CLOCK CYCLE : "+ i);
				System.out.println("Instruction : "+firstInst.getInstNum());
        		firstInst.printTest();
        		System.out.println();
        		System.out.println("Instruction : "+secInst.getInstNum());
        		secInst.printTest();
        		System.out.println();

        		
        		System.out.println("-------------------------------------------------------------");
                i++;

				System.out.println("CLOCK CYCLE : "+ i);
				System.out.println("Instruction : "+firstInst.getInstNum());
   
				mips.Memory(firstInst);
				firstInst.setMEM(true);
        		firstInst.setEX(false);
        		firstInst.printTest();
        		System.out.println();
        		
        		
        		mips.Execute(secInst);
        		secInst.setEX(true);
        		secInst.setID(false);
        		secInst.setStartExecute(1);
    			
        		
        		System.out.println("Instruction : "+secInst.getInstNum());
        		secInst.printTest();
        		System.out.println();
        		
        		
        		System.out.println("-------------------------------------------------------------");
                i++;
				System.out.println("CLOCK CYCLE : "+ i);
				System.out.println("Instruction : "+firstInst.getInstNum());
				mips.WriteBack(firstInst);
				firstInst.setWB(true);
        		firstInst.setMEM(false);
        		firstInst.printTest();
        		System.out.println();
        		
        		
        		secInst.setStartExecute(2);
        		System.out.println("Instruction : "+secInst.getInstNum());
        		secInst.printTest();
        		System.out.println();
        		
        		
        		System.out.println("-------------------------------------------------------------");
                i++;

				System.out.println("CLOCK CYCLE : "+ i);
        		System.out.println("Instruction : "+secInst.getInstNum());
        		mips.Memory(secInst);
				secInst.setMEM(true);
        		secInst.setEX(false);
    			
        		secInst.printTest();
        		System.out.println();
				
         		System.out.println("-------------------------------------------------------------");
                i++;

				System.out.println("CLOCK CYCLE : "+ i);
        		System.out.println("Instruction : "+secInst.getInstNum());
        		mips.WriteBack(secInst);
				secInst.setWB(true);
        		secInst.setMEM(false);
    			
        		secInst.printTest();
        		System.out.println();
        		
        		break;
    			
    		}
    			
                 //clk 1
    			 if( ( i==1 || AccumlatorReg.isEmpty())) {
    				if(AccEmpty==true) {
    					firstInst =mips.Fetch();
    					if(firstInst==null) {
    						fetchingInstFinished =true;
    					}
    					else {
    						firstInst  = mips.Fetch();
                            firstInst.setIF(true);
                        	instNum ++; 
                    		firstInst.setInstNum(instNum);
           
                    		AccumlatorReg.add(firstInst);
            				System.out.println("Instruction : "+firstInst.getInstNum());
                    		firstInst.printTest();
                    		System.out.println();
    					}
    					

    				}
    				else {

                    firstInst = AccumlatorReg.remove();
                    firstInst.setIF(true);
    				instNum ++; 
            		firstInst.setInstNum(instNum);
            		AccumlatorReg.add(firstInst);
    				System.out.println("Instruction : "+firstInst.getInstNum());
            		firstInst.printTest();
            		System.out.println();}
		
    			}
    			//clk 2
    			 else if (i%2 ==0 && AccumlatorReg.peek().getIF()==true) {

    				firstInst = AccumlatorReg.remove();
    				mips.Decode(firstInst);
    				firstInst.setStartDecode(1);
    				firstInst.setID(true);
    				firstInst.setIF(false);
    				if(firstInst.getOpcode().equals("0111")) {
    					firstInstJMPFLAG = true;
    					
    				}
    				if(firstInst.getOpcode().equals("0100")) {
    					firstInstJEQFLAG++;
    				}
    				AccumlatorReg.add(firstInst);
    				System.out.println("Instruction : "+firstInst.getInstNum());
            		firstInst.printTest();
            		System.out.println();
  
    			}
    			
    			 else if( firstInstJMPFLAG==true) {
    				
    				
					firstInst = AccumlatorReg.remove();
					
					firstInst.setStartDecode(2);
					System.out.println();
					firstInst.printTest();
					System.out.println();

					
					//i =4 
					i++;
					System.out.println("-------------------------------------------------------------");
    				System.out.println("CLOCK CYCLE : "+ i);
                    System.out.println();
    				mips.Execute(firstInst);
    				
    				firstInst.setEX(true);
    				firstInst.setID(false);
                    firstInst.setStartExecute(1);
                    firstInst.printTest();
					System.out.println();
                    i++;
					//i =5
                    
                	System.out.println("-------------------------------------------------------------");
    				System.out.println("CLOCK CYCLE : "+ i);
                    System.out.println();
                    firstInst.setStartExecute(2);
                    System.out.println();
					firstInst.printTest();
					System.out.println();
                    i++;
					//i =6
                	System.out.println("-------------------------------------------------------------");
    				System.out.println("CLOCK CYCLE : "+ i);
                    System.out.println();
                    
    				mips.Memory(firstInst);
    				firstInst.setEX(false);
    				firstInst.setMEM(true);
    				System.out.println();
					firstInst.printTest();
					System.out.println();
    				i++;
					//i =7

    				System.out.println("-------------------------------------------------------------");
    				System.out.println("CLOCK CYCLE : "+ i);
    				mips.WriteBack(firstInst);
    				firstInst.setWB(true);
    				firstInst.setMEM(false);
    				System.out.println();
					firstInst.printTest();
					System.out.println();
    		        i= i+1;
    		        System.out.println("i : " +i)
    				;
    		        System.out.println("size queue :" +AccumlatorReg.size());
    	            firstInstJMPFLAG =false;
    			
    				jmpFlag = true;
    			    AccEmpty = true;
    			    countUpd = true;

    				
    			}
                  
                 //clk 3
    		

    			 else if (i%2 !=0 && AccumlatorReg.peek().getID()==true && AccumlatorReg.peek().getStartDecode()==1 && firstInstJMPFLAG==false) {
    				Instruction secInst ;
    				firstInst = AccumlatorReg.remove();
    				firstInst.setStartDecode(2);
    				AccumlatorReg.add(firstInst);
 
    				

            		System.out.println("Instruction : "+firstInst.getInstNum());
                    firstInst.printTest();
            		System.out.println();
            		
            		secInst = mips.Fetch();
    				if(secInst == null) {
    					fetchingInstFinished =true;
    				}
    				else {
    					secInst.setIF(true);
        				instNum++;
        				secInst.setInstNum(instNum);
        				AccumlatorReg.add(secInst);
                        System.out.println("Instruction : "+secInst.getInstNum());
                		secInst.printTest();
                		System.out.println();

    					
    				}



			
    			}
    			//clk 4
    			 else if(i%2 ==0&& AccumlatorReg.peek().getID()== true&& AccumlatorReg.peek().getStartDecode()==2  ) {
//    				Instruction firstInst ;
    				Instruction secInst ; 

    				firstInst = AccumlatorReg.remove();
    			
    				mips.Execute(firstInst);
    				firstInst.setStartExecute(1);
    				firstInst.setEX(true);
    				firstInst.setID(false);
    				System.out.println();
    				firstInst.printTest();
    				System.out.println();
    				AccumlatorReg.add(firstInst);
    				if(firstInst.getOpcode().equals("0100")&& firstInst.getOutPutALU()!=0) {
    						firstInstJEQFLAG ++;
    						AccumlatorReg.remove();    					}
    					else
    					{
    						if(AccumlatorReg.size() !=1) {
    	        				secInst = AccumlatorReg.remove();
    	        				mips.Decode(secInst);
    	        				secInst.setStartDecode(1);
    	        				secInst.setID(true);
    	        				secInst.setIF(false);
    	        				if(secInst.getOpcode().equals("0111")) {
    	        					
    	        					secInstJMPFLAG = true;
    	        					
    	        				}
    	        				if(secInst.getOpcode().equals("0100")) {
    	        					secInstJEQFLAG ++;
    	        				}
    	        				AccumlatorReg.add(secInst);
    	                        System.out.println("Instruction : "+secInst.getInstNum());
    	                		secInst.printTest();
    	                		System.out.println();

    	    				}
    					}

    				}
    			 

    				
    	
    			 else 
    			      if( secInstJMPFLAG==true) {
      				
//  				
  					Instruction secInst;
  					firstInst = AccumlatorReg.remove();
  					secInst = AccumlatorReg.remove();
  					
  					firstInst.setStartExecute(2);
            		System.out.println("Instruction : "+firstInst.getInstNum());

  					System.out.println();
  					firstInst.printTest();
  					System.out.println();
  					
  					secInst.setStartDecode(2);
            		System.out.println("Instruction : "+secInst.getInstNum());

  					System.out.println();
  					secInst.printTest();
  					System.out.println();

  					
  					//i =6
  					i++;
  					System.out.println("-------------------------------------------------------------");
    				System.out.println("CLOCK CYCLE : "+ i);
      				System.out.println("Instruction : "+firstInst.getInstNum());

                    System.out.println();
      				mips.Memory(firstInst);
     				
      				firstInst.setMEM(true);
      				firstInst.setEX(false);

  					System.out.println();
  					firstInst.printTest();
  					System.out.println();
  					
  					mips.Execute(secInst);
  					secInst.setEX(true);
  					secInst.setID(false);
  					secInst.setStartExecute(1);
  					System.out.println("Instruction : "+secInst.getInstNum());

  					System.out.println();
  					secInst.printTest();
  					System.out.println();
                      i++;
              		System.out.println("-------------------------------------------------------------");
    				System.out.println("CLOCK CYCLE : "+ i);
                    System.out.println("Instruction : "+firstInst.getInstNum());

  					//i =7
                      
                      System.out.println();
                      mips.WriteBack(firstInst);
                      firstInst.setWB(true);
                      firstInst.setMEM(false);

    				System.out.println();
    				firstInst.printTest();
    				System.out.println();
  					secInst.setStartExecute(2);
  					System.out.println("Instruction : "+secInst.getInstNum());

  					System.out.println();
  					secInst.printTest();
  					System.out.println();
  					
  				
                      i++;
  					//i =8
              		System.out.println("-------------------------------------------------------------");
    				System.out.println("CLOCK CYCLE : "+ i);
                    System.out.println();
                      
      				mips.Memory(secInst);
      				secInst.setEX(false);
      				secInst.setMEM(true);
      				System.out.println("Instruction : "+secInst.getInstNum());

  					System.out.println();
  					secInst.printTest();
  					System.out.println();
      				i++;
  					//i =9

      				System.out.println("-------------------------------------------------------------");
    				System.out.println("CLOCK CYCLE : "+ i);
      				System.out.println("Instruction : "+secInst.getInstNum());

      				mips.WriteBack(secInst);
      				secInst.setWB(true);
      				secInst.setMEM(false);

  					System.out.println();
  					secInst.printTest();
  					System.out.println();
  				
      				i=i+1;
      	            secInstJMPFLAG =false;
      
      				jmpFlag = true;
    			    AccEmpty = true;
    			 
    			    countUpd =true;

      			    
      				
      			}
    			      else if (firstInstJEQFLAG ==2) {
    			    	  
    	  					firstInst = AccumlatorReg.remove();    	  					
    	  					firstInst.setStartExecute(2);
    	            		System.out.println("Instruction : "+firstInst.getInstNum());
    	  					System.out.println();
    	  					firstInst.printTest();
    	  					System.out.println();
    	  				
    	  					
    	  					i++;
    	  					System.out.println("-------------------------------------------------------------");
    	    				System.out.println("CLOCK CYCLE : "+ i);
    	      				System.out.println("Instruction : "+firstInst.getInstNum());

    	                    System.out.println();
    	      				mips.Memory(firstInst);
    	     				
    	      				firstInst.setMEM(true);
    	      				firstInst.setEX(false);

    	  					System.out.println();
    	  					firstInst.printTest();
    	  					System.out.println();
    	  					
    	  		
    	                    i++;
    	              		System.out.println("-------------------------------------------------------------");
    	    				System.out.println("CLOCK CYCLE : "+ i);
    	    				System.out.println("Instruction : "+firstInst.getInstNum());

    	                      
    	                    System.out.println();
    	                    mips.WriteBack(firstInst);
    	                    firstInst.setWB(true);
    	                    firstInst.setMEM(false);

    	    				System.out.println();
    	    				firstInst.printTest();
    	    				System.out.println();
	
    	      				i++;
                            firstInstJEQFLAG=0;    	      
    	      				jmpFlag = true;
    	    			    AccEmpty = true;
    	    			    countUpd =true;

    	  
    			}
    			else if(i%2 !=0 && AccumlatorReg.peek().getEX()==true&&  AccumlatorReg.peek().getStartExecute()==1 && secInstJMPFLAG ==false && firstInstJEQFLAG !=2){
    				
    				Instruction secInst ;
    				Instruction thirdInst ;
    			
    				firstInst = AccumlatorReg.remove();
    				secInst = AccumlatorReg.remove();
    			

    				
    				firstInst.setStartExecute(2);
    				secInst.setStartDecode(2);
    				
    				AccumlatorReg.add(firstInst);
    				AccumlatorReg.add(secInst);

    			
    				
    				System.out.println("Instruction : "+firstInst.getInstNum());
                    firstInst.printTest();
            		System.out.println();

                    System.out.println("Instruction : "+secInst.getInstNum());
            		secInst.printTest();
            		System.out.println();
            		
            		thirdInst = mips.Fetch();
    				if(thirdInst== null) {
    					fetchingInstFinished =true;
    				}
    				else {
    					thirdInst.setIF(true);
        				instNum++;
        				thirdInst.setInstNum(instNum);
        				AccumlatorReg.add(thirdInst);
        				 System.out.println("Instruction : "+thirdInst.getInstNum());
                 		thirdInst.printTest();
                 		System.out.println();

    				}

                   

            		
    			}
    			//clk 6
    			else if(i%2 ==0 && AccumlatorReg.peek().getEX()==true && AccumlatorReg.peek().getStartExecute()==2&& fetchingInstFinished ==false  ) {

    				Instruction secInst ;
    				Instruction thirdInst ;
    				
    				firstInst = AccumlatorReg.remove();
    				secInst = AccumlatorReg.remove();
    				thirdInst = AccumlatorReg.remove();
    				mips.Memory(firstInst);
    				firstInst.setMEM(true);
    				firstInst.setEX(false);
    				mips.Execute(secInst);
    				secInst.setStartExecute(1);
    				secInst.setEX(true);
    				secInst.setID(false);
    				
    				
    				if(secInst.getOpcode().equals("0100")&& secInst.getOutPutALU()!=0) {
    					secInstJEQFLAG++;
    					AccumlatorReg.add(firstInst);
        				AccumlatorReg.add(secInst);
        				System.out.println("Instruction : "+firstInst.getInstNum());
                        firstInst.printTest();
                		System.out.println();

                        System.out.println("Instruction : "+secInst.getInstNum());
                		secInst.printTest();
                		System.out.println();
    						
    				}
    				else {
    					mips.Decode(thirdInst);
        				thirdInst.setStartDecode(1);
        				thirdInst.setID(true);
        				thirdInst.setIF(false);
                        if(thirdInst.getOpcode().equals("0111")) {
                        	
                        	thirdInstJMPFLAG =true;
        					
        				}
                        if(thirdInst.getOpcode().equals("0100")) {
                        	secInstJEQFLAG++;
                        }
                        System.out.println("Instruction : "+firstInst.getInstNum());
                        firstInst.printTest();
                		System.out.println();
                		AccumlatorReg.add(firstInst);
        				AccumlatorReg.add(secInst);

                        System.out.println("Instruction : "+secInst.getInstNum());
                		secInst.printTest();
                		System.out.println();
        				AccumlatorReg.add(thirdInst);
        				System.out.println("Instruction : "+thirdInst.getInstNum());
                		thirdInst.printTest();
                		System.out.println();

    				}
    							
    			}
    			else  if(thirdInstJMPFLAG==true) {
      				
//					i++;
					//7
					Instruction secInst;
					Instruction thirdInst;
		

					firstInst = AccumlatorReg.remove();
					secInst = AccumlatorReg.remove();
					thirdInst = AccumlatorReg.remove();
					
					mips.WriteBack(firstInst);
					firstInst.setWB(true);
					firstInst.setMEM(false);
					System.out.println("Instruction : "+firstInst.getInstNum());

					System.out.println();
					firstInst.printTest();
					System.out.println();
					
					secInst.setStartExecute(2);
					System.out.println("Instruction : "+secInst.getInstNum());

					System.out.println();
					secInst.printTest();
					System.out.println();
					thirdInst.setStartDecode(2);
					System.out.println("Instruction : "+thirdInst.getInstNum());

					System.out.println();
					thirdInst.printTest();
					System.out.println();

					
					i++;
					//i =8
              		System.out.println("-------------------------------------------------------------");

	  				System.out.println("CLOCK CYCLE : "+ i);
	                System.out.println();
	  				mips.Memory(secInst);
	  				
	  				secInst.setMEM(true);
	  				secInst.setEX(false);
	  				System.out.println("Instruction : "+secInst.getInstNum());

					System.out.println();
					secInst.printTest();
					System.out.println();
					
					mips.Execute(thirdInst);
						thirdInst.setEX(true);
						thirdInst.setID(false);
						thirdInst.setStartExecute(1);
						System.out.println("Instruction : "+thirdInst.getInstNum());
	
						System.out.println();
						thirdInst.printTest();
						System.out.println();
	                   i++;
						//i =9
	              		System.out.println("-------------------------------------------------------------");

		              	  System.out.println("CLOCK CYCLE : "+ i);
		                  System.out.println();
		                  mips.WriteBack(secInst);
		                  secInst.setWB(true);
		                  secInst.setMEM(false);
		                  System.out.println();
		                  System.out.println("Instruction : "+secInst.getInstNum());
	
						System.out.println();
						secInst.printTest();
						System.out.println();
						thirdInst.setStartExecute(2);
					System.out.println("Instruction : "+thirdInst.getInstNum());

					System.out.println();
					thirdInst.printTest();
					System.out.println();
					
					
				
					i++;
					//i =10
              		System.out.println("-------------------------------------------------------------");

                  	System.out.println("CLOCK CYCLE : "+ i);
                  	System.out.println();
                  
  					mips.Memory(thirdInst);
  					thirdInst.setEX(false);
  					thirdInst.setMEM(true);
  					System.out.println("Instruction : "+thirdInst.getInstNum());

					System.out.println();
					thirdInst.printTest();
					System.out.println();
					i++;
					//i =11
              		System.out.println("-------------------------------------------------------------");


  					System.out.println("CLOCK CYCLE : "+ i);
  					mips.WriteBack(thirdInst);
  					thirdInst.setWB(true);
  					thirdInst.setMEM(false);
  					System.out.println("Instruction : "+thirdInst.getInstNum());

					System.out.println();
					thirdInst.printTest();
					System.out.println();
					System.out.println("pc data :"+mips.getPc().getData());

  		        i= i+1;
  		        
  		        thirdInstJMPFLAG =false;
  		        

  				jmpFlag = true;
			    AccEmpty = true;
			    countUpd =true;

    
  				
  			}
    			else if (secInstJEQFLAG ==2) {
    				
    				firstInst = AccumlatorReg.remove();
    				Instruction secInst = AccumlatorReg.remove();
    				
    				mips.WriteBack(firstInst);
    				firstInst.setMEM(false);
    				firstInst.setWB(true);
    				System.out.println();
    				firstInst.printTest();
    				System.out.println();
                    
    				secInst.setStartExecute(2);
    				System.out.println();
    				secInst.printTest();
    				System.out.println();
              		System.out.println("-------------------------------------------------------------");

    				i++;
    				System.out.println("CLOCK CYCLE : "+ i);
                    System.out.println(); 
                    
                    mips.Memory(secInst);
                    secInst.setMEM(true);
                    secInst.setEX(false);
                	System.out.println();
    				secInst.printTest();
    				System.out.println();
              		System.out.println("-------------------------------------------------------------");

    				i++;
    				System.out.println("CLOCK CYCLE : "+ i);
                    System.out.println(); 
                    
                    mips.WriteBack(secInst);
                    secInst.setWB(true);
                    secInst.setMEM(false);
                	System.out.println();
    				secInst.printTest();
    				System.out.println();
    				
    				i++;
    				jmpFlag =true;
    				secInstJEQFLAG=0;
    				AccEmpty =true;	
    			    countUpd =true;

    				
    				
    			}
				
    			//clk7
    			else if(i%2 !=0 &&AccumlatorReg.peek().getMEM()==true && fetchingInstFinished ==false && thirdInstJMPFLAG ==false && secInstJEQFLAG !=2
    					) {
    				
    				Instruction secInst ;
    				Instruction thirdInst ;
    				Instruction fourthInst ;
    			
    				
    				firstInst = AccumlatorReg.remove();
    				secInst = AccumlatorReg.remove();
    				thirdInst = AccumlatorReg.remove();
    				
    				mips.WriteBack(firstInst);
    				firstInst.setWB(true);
    				firstInst.setMEM(false);
    				
    				secInst.setStartExecute(2);
    				thirdInst.setStartDecode(2);
    				
    				
    				AccumlatorReg.add(secInst);
    				AccumlatorReg.add(thirdInst);

    				
    				System.out.println("Instruction : "+firstInst.getInstNum());
                    firstInst.printTest();
            		System.out.println();

                    System.out.println("Instruction : "+secInst.getInstNum());
            		secInst.printTest();
            		System.out.println();

                    System.out.println("Instruction : "+thirdInst.getInstNum());
            		thirdInst.printTest();
            		System.out.println();
            		
            		
             		
             		fourthInst = mips.Fetch();
    				if(fourthInst== null) {
    					fetchingInstFinished =true;
    				}
    				else {
    					fourthInst.setIF(true);
        				instNum++;
        				fourthInst.setInstNum(instNum);
        				AccumlatorReg.add(fourthInst);
        				 System.out.println("Instruction : "+fourthInst.getInstNum());
                 		fourthInst.printTest();
                 		System.out.println();

    				}
    				
    			}
    			//clk 8
    			
//    			else if(i%2 ==0 && AccumlatorReg.peek().getEX()==true &&   && fetchingInstFinished ==false) {   
//    				Instruction secInst ;
//    				Instruction thirdInst ;
//    			
//    				
//    				firstInst = AccumlatorReg.remove();
//    				secInst = AccumlatorReg.remove();
//    				thirdInst = AccumlatorReg.remove(); 
// 
//    				
//    				mips.Memory(firstInst);
//    				firstInst.setMEM(true);
//    				firstInst.setEX(false);
//    				
//    				mips.Execute(secInst);
//    				secInst.setStartExecute(1);
//    				secInst.setEX(true);
//    				secInst.setID(false);
//    				
//    				mips.Decode(thirdInst);
//    				thirdInst.setStartDecode(1);
//    				thirdInst.setID(true);
//    				thirdInst.setIF(false);
//                    if(thirdInst.getOpcode().equals("0111")) {
//                    	thirdInstJMPFLAG2  =true;
//    					
//    				}
//    		
//    				AccumlatorReg.add(firstInst);
//    				AccumlatorReg.add(secInst);
//    				AccumlatorReg.add(thirdInst);
//    				
//    				System.out.println("Instruction : "+firstInst.getInstNum());
//                    firstInst.printTest();
//            		System.out.println();
//
//                    System.out.println("Instruction : "+secInst.getInstNum());
//            		secInst.printTest();
//            		System.out.println();
//
//                    System.out.println("Instruction : "+thirdInst.getInstNum());
//            		thirdInst.printTest();
//            		System.out.println();
//    				
//    			}
    	
    			 
    			else  if(thirdInstJMPFLAG2==true) {
      				
  					//7
  					Instruction secInst;
  					Instruction thirdInst;
  		

  					firstInst = AccumlatorReg.remove();
  					secInst = AccumlatorReg.remove();
  					thirdInst = AccumlatorReg.remove();
  					
  					mips.WriteBack(firstInst);
  					firstInst.setWB(true);
  					firstInst.setMEM(false);
  					System.out.println("Instruction : "+firstInst.getInstNum());

  					System.out.println();
  					firstInst.printTest();
  					System.out.println();
  					
  					secInst.setStartExecute(2);
  					System.out.println("Instruction : "+secInst.getInstNum());

  					System.out.println();
  					secInst.printTest();
  					System.out.println();
  					thirdInst.setStartDecode(2);
  					System.out.println("Instruction : "+thirdInst.getInstNum());

  					System.out.println();
  					thirdInst.printTest();
  					System.out.println();

  					
  					i++;
  					//i =8
              		System.out.println("-------------------------------------------------------------");

      				System.out.println("CLOCK CYCLE : "+ i);
                      System.out.println();
      				mips.Memory(secInst);
      				
      				secInst.setMEM(true);
      				secInst.setEX(false);
      				System.out.println("Instruction : "+secInst.getInstNum());

  					System.out.println();
  					secInst.printTest();
  					System.out.println();
  					
  					mips.Execute(thirdInst);
  					thirdInst.setEX(true);
  					thirdInst.setID(false);
  					thirdInst.setStartExecute(1);
  					System.out.println("Instruction : "+thirdInst.getInstNum());

  					System.out.println();
  					thirdInst.printTest();
  					System.out.println();
                      i++;
  					//i =9
                	System.out.println("-------------------------------------------------------------");

                  	System.out.println("CLOCK CYCLE : "+ i);
                    System.out.println("Instruction : "+secInst.getInstNum());

                      System.out.println();
                      mips.WriteBack(secInst);
                      secInst.setWB(true);
                      secInst.setMEM(false);
                      System.out.println();

    					System.out.println();
    					secInst.printTest();
    					System.out.println();
  					thirdInst.setStartExecute(2);
  					System.out.println("Instruction : "+thirdInst.getInstNum());

  					System.out.println();
  					thirdInst.printTest();
  					System.out.println();
  					
  					
              		System.out.println("-------------------------------------------------------------");

                      i++;
  					//i =10
                      System.out.println("CLOCK CYCLE : "+ i);
                      System.out.println();
                      
      				mips.Memory(thirdInst);
      				thirdInst.setEX(false);
      				thirdInst.setMEM(true);
      				System.out.println("Instruction : "+thirdInst.getInstNum());

  					System.out.println();
  					thirdInst.printTest();
  					System.out.println();
      				i++;
  					//i =11
              		System.out.println("-------------------------------------------------------------");

      				System.out.println("CLOCK CYCLE : "+ i);
      				mips.WriteBack(thirdInst);
      				thirdInst.setWB(true);
      				thirdInst.setMEM(false);
      				System.out.println("Instruction : "+thirdInst.getInstNum());

  					System.out.println();
  					thirdInst.printTest();
  					System.out.println();
    			    System.out.println("pc data :"+mips.getPc().getData());

      		        i= i+1;
      		        
      		        thirdInstJMPFLAG =false;
      		        
   
      				jmpFlag = true;
    			    AccEmpty = true;
                    countUpd =true;
      				
      			}
  				
         
    			else if(fetchingInstFinished ==true) {
    			
    			if(i%2 !=0 &&AccumlatorReg.peek().getMEM()==true &&  AccumlatorReg.size()==3 ) {
    				Instruction secInst ;
    				Instruction thirdInst ;
    				
                    
    				firstInst = AccumlatorReg.remove();
    				secInst = AccumlatorReg.remove();
    				thirdInst = AccumlatorReg.remove();
    				
    				
    				mips.WriteBack(firstInst);
    				firstInst.setWB(true);
    				firstInst.setMEM(false);
    				
    				secInst.setStartExecute(2);
    				thirdInst.setStartDecode(2);

    				
    				AccumlatorReg.add(secInst);
    				AccumlatorReg.add(thirdInst);
    				System.out.println(AccumlatorReg.size());
    				System.out.println("Instruction : "+firstInst.getInstNum());
                    firstInst.printTest();
            		System.out.println();

                    System.out.println("Instruction : "+secInst.getInstNum());
            		secInst.printTest();
            		System.out.println();

                    System.out.println("Instruction : "+thirdInst.getInstNum());
            		thirdInst.printTest();
            		System.out.println();
      
            		System.out.println();
    			}

    			
    			//clk 16
    			else  if(i%2 ==0 && AccumlatorReg.peek().getEX()==true  &&AccumlatorReg.size()==2 ) {
      				
      				Instruction secInst ;

      				firstInst = AccumlatorReg.remove();
      				secInst = AccumlatorReg.remove();
      				
      				mips.Memory(firstInst);
      				firstInst.setMEM(true);
      				firstInst.setEX(false);
      				
      				mips.Execute(secInst);
      				secInst.setStartExecute(1);
      				secInst.setEX(true);
      				secInst.setID(false);
      				
      				AccumlatorReg.add(firstInst);
      				AccumlatorReg.add(secInst);
      				
      				
      				System.out.println("Instruction : "+firstInst.getInstNum());
                    firstInst.printTest();
            		System.out.println();

                    System.out.println("Instruction : "+secInst.getInstNum());
            		secInst.printTest();
            		System.out.println();

                   
      				
      			}
    		    //clk 17
    			else if(i%2 !=0 &&AccumlatorReg.peek().getMEM()==true && AccumlatorReg.size()==2) {
    				
      				Instruction secInst ;

    				firstInst = AccumlatorReg.remove();
    				secInst = AccumlatorReg.remove();
    				mips.WriteBack(firstInst);
    				firstInst.setWB(true);
    				firstInst.setMEM(false);
    				secInst.setStartExecute(2);

    				AccumlatorReg.add(secInst);

    				System.out.println("Instruction : "+firstInst.getInstNum());
                    firstInst.printTest();
            		System.out.println();

                    System.out.println("Instruction : "+secInst.getInstNum());
            		secInst.printTest();
            		System.out.println();

               
    			}
    			//clk 18

    			else if(i%2 ==0 && AccumlatorReg.peek().getEX()==true && AccumlatorReg.size()==1) {
       				

       				firstInst = AccumlatorReg.remove();
       				
       				mips.Memory(firstInst);
       				firstInst.setMEM(true);
       				firstInst.setEX(false);
       			
     
       				AccumlatorReg.add(firstInst);

       				System.out.println("Instruction : "+firstInst.getInstNum());
                    firstInst.printTest();
            		System.out.println();

                   				
       			}
    			else {
    				if(i%2 !=0 &&AccumlatorReg.peek().getMEM()==true&& AccumlatorReg.size()==1  ) {
    			


    				firstInst = AccumlatorReg.remove();
    				mips.WriteBack(firstInst);
    				firstInst.setWB(true);
    				firstInst.setMEM(false);
    				
    				endPipelining = true;
    				AccEmpty = true;

       				System.out.println("Instruction : "+firstInst.getInstNum());
                    firstInst.printTest();
            		System.out.println();
    			       }
    		       }
    	      }
    
               i++;

            };

    	    System.out.println("-----------------------------------------------");
    		System.out.println("RegFile Buffer :");
    		System.out.println();
    		for(int k =0 ; k<mips.getRegfile().getRegfileBuffer().length;k++) {
    			System.out.println("R"+(k+1)+" "+mips.getRegfile().getRegfileBuffer()[k].getData());
    		}
    		System.out.println();
    	    System.out.println("-----------------------------------------------");
    		System.out.println("Instruction Memory : ");
    		System.out.println();
    		
    		for(int j =0 ; j<mips.getMemory().getMemoryBuffer().length-1024;j++) {

        			System.out.println(j+" :"+mips.getMemory().getMemoryBuffer()[j]);
    		}
    		System.out.println();
    	    System.out.println("-----------------------------------------------");
    	    System.out.println("Data Memory : ");
        	System.out.println();

    		for(int l =1024 ; l<mips.getMemory().getMemoryBuffer().length;l++) {
        			System.out.println(l+" :"+mips.getMemory().getMemoryBuffer()[l]);
   
    		}
    	}
    }
    	
    
      	  public static void main(String[] args) throws IOException {

        	    mips = new Processor(); 

        	    mips.getMemory().loadInstructions();
                mips.getMemory().getMemoryBuffer()[1045] = "00000000000000000000000000000011"    ;   
                mips.getMemory().getMemoryBuffer()[1034] = "00000000000000000000000000000101"    ;   
                mips.getMemory().getMemoryBuffer()[1029] = "11111111111111111111111111111100"    ;
                

                
               

                mips.getRegfile().getRegfileBuffer()[1].setData(8);
                mips.getRegfile().getRegfileBuffer()[2].setData(8);
                PipeLine p = new PipeLine();

//                int number = -10;
//                String formattedString = String.format("%-8d", number);
//                System.out.println(formattedString);
////                
//                String binaryString = "11111111111111111111111111110110"; // Example binary string in negative format
//                int number = Integer.parseInt(String.format("%s", binaryString), 2);
//                System.out.println(number);
                
//                String binary = Integer.toBinaryString(-54);
//                String b ="11111111001010";
//				int shamtInt = Integer.parseInt("-5");
//                System.out.println(b);
//
//                long l = Long.parseLong(b, 2);
//                
//                int i = (int) l;
//                System.out.println(shamtInt);



                p.pipeline();
//             String binaryString = "-2"; // Example binary string (negative number)
//
//             // Convert binary string to integer
//             int number = Integer.parseInt(binaryString);
//
//             // Perform addition
//             int result = number +3
//            		 ; // Example addition operation
//
//             // Display result
//             System.out.println(result);
//                String binaryString = "11111111111111111111111111011010";
//                int length = binaryString.length();
//
//                int decimal = Integer.parseInt(binaryString, 2);
//                decimal -= Math.pow(2, length - 1);
//
//                System.out.println(decimal);
//                // Output: -42
        	  }



}
