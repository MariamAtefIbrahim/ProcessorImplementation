package MIPS;
import java.io.PrintWriter;

import Instructions.*;

public class Processor {
	private static Memory Memory ;
	private static ALU Alu;
	private static RegFile Regfile;
	private static Register pc;
	private static  Register R0 ;
	private String destReg ;
	private String OperandR1 ;
	private String OperandR2 ;
	private Instruction inst;
	private String binaryDataMemory;
	private String opcode;
	private String fetchedInst ;

	

	public Processor() {
		this.Memory = new Memory();
		this.Alu = new ALU();
		this.Regfile = new RegFile();
		this.pc = new Register("PC");
		this.R0 = new Register("R0");
		this.R0.setData(0);
		this.pc.setData(0);
	}
	
	public Instruction  Fetch() {
	    fetchedInst = Memory.getMemoryBuffer()[pc.getData()]; 
	    if(fetchedInst ==null) {
	    	return null;
	    }
	    int startIndexOpcode =0 ;
		int endIndexOpcode = 4;
		opcode = fetchedInst.substring(startIndexOpcode, endIndexOpcode);
		inst = Instruction.createInst(opcode);
		inst.setOpcode(opcode);
		inst.setFetchedInst(fetchedInst);
	    this.pc.setData(this.pc.getData()+1);
	    return inst ;
	    
	}
	public void Decode(Instruction inst) {

		int [] result = new int[5];
		switch(inst.getInst_type()) {
		case R_type :
					int startIndexR1 =4 ;
					int endIndexR1 =9;
					String r1 = inst.getFetchedInst().substring(startIndexR1, endIndexR1);
					int startIndexR2 = 9 ;
					int endIndexR2 = 14;
					String r2 = inst.getFetchedInst().substring(startIndexR2, endIndexR2);
					int startIndexR3 = 14 ;
					int endIndexR3 = 19;
					String r3 = inst.getFetchedInst().substring(startIndexR3, endIndexR3);
					int startIndexSHAMT = 19 ;
					int endIndexSHAMT =32;
					String SHAMT = inst.getFetchedInst().substring(startIndexSHAMT, endIndexSHAMT);
					if(SHAMT.charAt(0)=='1') {
						while(SHAMT.length()<32) {
							SHAMT = "1"+SHAMT;
						}
					}
					String r1conv = this.Regfile.convBinaryToReg(r1);
					String r2conv = this.Regfile.convBinaryToReg(r2);
					String r3conv = this.Regfile.convBinaryToReg(r3);
					int SHAMTint;
					if(SHAMT.charAt(0)=='1') {
						
					     long l = Long.parseLong(SHAMT, 2);
			               
			              SHAMTint = (int) l;
					}
					else {
						 SHAMTint = Integer.parseInt(SHAMT,2);
	
					}
					inst.setRd( Integer.parseInt(r3,2)); 
					inst.setRs( Integer.parseInt(r1,2));
					if(!inst.getOpcode().equals("1000")  ) {
						if(!inst.getOpcode().equals("1001")) {
							inst.setRt( Integer.parseInt(r2,2));
						    inst.setRtString(r2conv); 
						}
						else {
							inst.setRtString(null);
							inst.setRt(0);
							
						}
						

					}
				
					else {
						inst.setRtString(null);
						inst.setRt(0);
						
					}
				    inst.setRdString(r3conv);
				    inst.setRsString(r1conv); 
				    inst.setShamt(SHAMTint);
			        ;break;
			        
		case I_type :
					int startIndexR1_I =4 ;
					int endIndexR1_I =9;
					String r1I = inst.getFetchedInst().substring(startIndexR1_I, endIndexR1_I);
					int startIndexR2_I = 9 ;
					int endIndexR2_I = 14;
					String r2I = inst.getFetchedInst().substring(startIndexR2_I, endIndexR2_I);						
					int startIndexIMMEDIATE = 14;
					int endIndexIMMEDIATE =32;
					String IMMEDIATE = inst.getFetchedInst().substring(startIndexIMMEDIATE, endIndexIMMEDIATE);
					String r1convI = this.Regfile.convBinaryToReg(r1I);
					String r2convI = this.Regfile.convBinaryToReg(r2I);
					if(inst.getOpcode().equals("0100")) {
						inst.setRt( Integer.parseInt(r1I,2)); 
						inst.setRs( Integer.parseInt(r2I,2));
						inst.setRtString(r1convI); 
						inst.setRsString(r2convI); 
					}
					else if(inst.getOpcode().equals("0011")){
						inst.setRd( Integer.parseInt(r2I,2)); 
						inst.setRdString(r2convI); 
	 
					}
					else {
						inst.setRd( Integer.parseInt(r2I,2)); 
						inst.setRs( Integer.parseInt(r1I,2));
						inst.setRdString(r2convI); 
						inst.setRsString(r1convI); 
					}
					if(IMMEDIATE.charAt(0)=='1') {
						while(IMMEDIATE.length()<32) {
							IMMEDIATE = "1"+IMMEDIATE;
						}
					}
					int IMMEDIATEint;
					if(IMMEDIATE.charAt(0)=='1') {
						
					     long l = Long.parseLong(IMMEDIATE,2);
			               
					     IMMEDIATEint = (int) l;
					}
					else {
						IMMEDIATEint  = Integer.parseInt(IMMEDIATE,2);
	
					}
					
					inst.setImmediate(IMMEDIATEint);
					;break;
					
		case J_type :						
					int startIndexADDRESS = 14;
					int endIndexADDRESS =32;
					String ADDRESS = inst.getFetchedInst().substring(startIndexADDRESS, endIndexADDRESS);
					int ADDRESSint = Integer.parseInt(ADDRESS,2);	
					inst.setAddress(ADDRESSint);
					;break;
		}


		
	}
	public void Execute(Instruction inst) {
		int data1 =0;
		int data2 =0;
		if(inst.getRsString()!= null){
			if(inst.getRs()==0) {
				data1 = this.getR0().getData();
			}
			else {
				 data1 = this.Regfile.getRegfileBuffer()[inst.getRs()-1].getData();

			}
		}
		if(inst.getRtString()!=null) {
			if(inst.getRt()==0) {
				data2 = this.getR0().getData();
			}
			else {
				data2 = this.Regfile.getRegfileBuffer()[inst.getRt()-1].getData();

			}
		}
		int opcodeINT = Integer.parseInt(inst.getOpcode(),2);
		inst.setOutPutALU(Alu.ALU(data1, data2, opcodeINT , inst.getImmediate(), inst.getShamt(), inst.getAddress()));

	
	}
	
	
	
	public void Memory(Instruction inst) {
		if(inst.getOpcode().equals("1010")) {
			System.out.println("outputALU :"+ inst.getOutPutALU());
			String word = Processor.getMemory().getMemoryBuffer()[inst.getOutPutALU()+1024];
			int output;
			if(word.charAt(0)=='1') {
				
			     long l = Long.parseLong(word, 2);
	               
	              output = (int) l;
				
			}
			else {
				output  = Integer.parseInt(word,2);
			}
	        inst.setOutPutMEM(output); 

		}
		if(inst.getOpcode().equals("1011") && inst.getRd()!=0) {
		    binaryDataMemory = Integer.toBinaryString(Processor.Regfile.getRegfileBuffer()[inst.getRd()-1].getData());
		    
			while(binaryDataMemory.length()<32)
			{
				binaryDataMemory = "0" + binaryDataMemory;		
			}
			Processor.getMemory().getMemoryBuffer()[inst.getOutPutALU()+1024] = binaryDataMemory;
			inst.setMemorySavedNewData(Integer.parseInt(binaryDataMemory,2));
			System.out.println("Memory Address  : "+(inst.getOutPutALU()+1024));

			System.out.println("DataSavedToMemAddress : "+inst.getMemorySavedNewData());
			

		}

	
		
	}
	
	public void WriteBack(Instruction inst) {
		if(inst.getOpcode().equals("0111")) {
			Processor.getPc().setData(inst.getOutPutALU()-1);
		}
		if(inst.getOpcode().equals("0100")&& inst.getOutPutALU()!=0) {
			System.out.println("out :"+ inst.getOutPutALU());
			System.out.println("pc inside wb  :"+ Processor.getPc().getData());

			Processor.getPc().setData(inst.getOutPutALU()+Processor.getPc().getData()-2);

		}
		if(inst.getOpcode().equals("1010")) {
			 this.Regfile.getRegfileBuffer()[inst.getRd()-1].setData(inst.getOutPutMEM());
			 System.out.println("-----------------------------------------------------------------------------");
			 System.out.println("DestReg updated data : "+ this.Regfile.getRegfileBuffer()[inst.getRd()-1].getData());
			
		}
		if(inst.getRdString() != null && inst.getRd()!=0 && !inst.getOpcode().equals("1011") && !inst.getOpcode().equals("1010")) {
			 this.Regfile.getRegfileBuffer()[inst.getRd()-1].setData(inst.getOutPutALU());
			 System.out.println("-----------------------------------------------------------------------------");
			 System.out.println("DestReg updated data : "+ this.Regfile.getRegfileBuffer()[inst.getRd()-1].getData());
		} 
		
		
		
	}
	


	
	
	
	public static Memory getMemory() {
		return Memory;
	}
	public void setMemory(Memory memory) {
		Memory = memory;
	}
	public ALU getAlu() {
		return Alu;
	}
	public void setAlu(ALU alu) {
		Alu = alu;
	}
	public RegFile getRegfile() {
		return Regfile;
	}
	public void setRegfile(RegFile regfile) {
		Regfile = regfile;
	}
	public static Register getPc() {
		return pc;
	}
	public static void setPc(Register pc) {
		Processor.pc = pc;
	}
	public static Register getR0() {
		return R0;
	}
	public static void setR0(Register r0) {
		R0 = r0;
	}

	public String getDestReg() {
		return destReg;
	}

	public void setDestReg(String destReg) {
		this.destReg = destReg;
	}

	public String getOperandR1() {
		return OperandR1;
	}

	public void setOperandR1(String operandR1) {
		OperandR1 = operandR1;
	}

	public String getOperandR2() {
		return OperandR2;
	}

	public void setOperandR2(String operandR2) {
		OperandR2 = operandR2;
	}



	public Instruction getInst() {
		return inst;
	}

	public void setInst(Instruction inst) {
		this.inst = inst;
	}

	public String getBinaryDataMemory() {
		return binaryDataMemory;
	}

	public void setBinaryDataMemory(String binaryDataMemory) {
		this.binaryDataMemory = binaryDataMemory;
	}

	

}
