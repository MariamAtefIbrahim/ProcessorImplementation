package MIPS;
import MIPS.Register;

public class RegFile {
	private static Register[] regfileBuffer ;
	
	public RegFile() {
		regfileBuffer = new Register[31];
		for(int i =0; i<regfileBuffer.length ; i++) {
		this.regfileBuffer[i] = new Register("R"+(i+1));
		
		}
	}
public static String convRegtoBinary(String RegName) {
		String RegBinary = "";
		switch(RegName) {
		case "R0" :  RegBinary = "00000";
		             Processor.getR0().setAddress(RegBinary);break;
		case "R1":   RegBinary = "00001";
				     regfileBuffer[0].setAddress(RegBinary);break;
		case "R2":   RegBinary = "00010";
					 regfileBuffer[1].setAddress(RegBinary);break;
		case "R3":   RegBinary = "00011";
	                 regfileBuffer[2].setAddress(RegBinary);break;
		case "R4":   RegBinary = "00100";
					 regfileBuffer[3].setAddress(RegBinary);break;
		case "R5":   RegBinary = "00101";
					 regfileBuffer[4].setAddress(RegBinary);break;
		case "R6":   RegBinary = "00110";
					 regfileBuffer[5].setAddress(RegBinary);break;
		case "R7":   RegBinary = "00111";
					 regfileBuffer[6].setAddress(RegBinary);break;
		case "R8":   RegBinary = "01000";
					 regfileBuffer[7].setAddress(RegBinary);break;
		case "R9": 	 RegBinary = "01001";
					 regfileBuffer[8].setAddress(RegBinary);break;
		case "R10":  RegBinary = "01010";
	                 regfileBuffer[9].setAddress(RegBinary);break;
		case "R11":  RegBinary = "01011";
				     regfileBuffer[10].setAddress(RegBinary);break;
		case "R12":  RegBinary = "01100";
	                 regfileBuffer[11].setAddress(RegBinary);break;
		case "R13":  RegBinary = "01101";
					 regfileBuffer[12].setAddress(RegBinary);break;
		case "R14":  RegBinary = "01110";
					 regfileBuffer[13].setAddress(RegBinary);break;
		case "R15":  RegBinary = "01111";
	                 regfileBuffer[14].setAddress(RegBinary);break;
		case "R16":  RegBinary = "10000";
	                 regfileBuffer[15].setAddress(RegBinary);break;
		case "R17":  RegBinary = "10001";
					 regfileBuffer[16].setAddress(RegBinary);break;
		case "R18":  RegBinary = "10010";
	                 regfileBuffer[17].setAddress(RegBinary);break;
		case "R19":  RegBinary = "10011";
	                 regfileBuffer[18].setAddress(RegBinary);break;
		case "R20":  RegBinary = "10100";
					 regfileBuffer[19].setAddress(RegBinary);break;
		case "R21":  RegBinary = "10101";
					 regfileBuffer[20].setAddress(RegBinary);break;
		case "R22":  RegBinary = "10110";
					 regfileBuffer[21].setAddress(RegBinary);break;
		case "R23":  RegBinary = "10111";
	           		 regfileBuffer[22].setAddress(RegBinary);break;
		case "R24":  RegBinary = "11000";
					 regfileBuffer[23].setAddress(RegBinary);break;
		case "R25":  RegBinary = "11001";
					 regfileBuffer[24].setAddress(RegBinary);break;
		case "R26":  RegBinary = "11010";
					 regfileBuffer[25].setAddress(RegBinary);break;
		case "R27":  RegBinary = "11011";
					 regfileBuffer[26].setAddress(RegBinary);break;
		case "R28":  RegBinary = "11100";
					 regfileBuffer[27].setAddress(RegBinary);break;
		case "R29":  RegBinary = "11101";
	     			 regfileBuffer[28].setAddress(RegBinary);break;
		case "R30":  RegBinary = "11110";
					 regfileBuffer[29].setAddress(RegBinary);break;
		case "R31":  RegBinary = "11111";
					 regfileBuffer[30].setAddress(RegBinary);break;
	
		}
		
		
		return RegBinary;
	}
public static int getRegData(String RegName) {
	int RegBinary = 0  ;
	switch(RegName) {
	case "R0" :  RegBinary = 0;
	            ;break;
	case "R1":   RegBinary = regfileBuffer[0].getData();
			;break;
	case "R2":   RegBinary = regfileBuffer[1].getData();;
				 ;break;
	case "R3":   RegBinary = regfileBuffer[2].getData();;
               ;break;
	case "R4":   RegBinary = regfileBuffer[3].getData();;
				 ;break;
	case "R5":   RegBinary = regfileBuffer[4].getData();;
				 ;break;
	case "R6":   RegBinary = regfileBuffer[5].getData();;
				 ;break;
	case "R7":   RegBinary = regfileBuffer[6].getData();;
				;break;
	case "R8":   RegBinary = regfileBuffer[7].getData();;
				;break;
	case "R9": 	 RegBinary = regfileBuffer[8].getData();;
				;break;
	case "R10":  RegBinary = regfileBuffer[9].getData();;
               ;break;
	case "R11":  RegBinary = regfileBuffer[10].getData();;
			;break;
	case "R12":  RegBinary =regfileBuffer[11].getData();;
               ;break;
	case "R13":  RegBinary = regfileBuffer[12].getData();;
				 ;break;
	case "R14":  RegBinary = regfileBuffer[13].getData();;
				;break;
	case "R15":  RegBinary =regfileBuffer[14].getData();;
                ;break;
	case "R16":  RegBinary = regfileBuffer[15].getData();;
               ;break;
	case "R17":  RegBinary = regfileBuffer[16].getData();;
				;break;
	case "R18":  RegBinary = regfileBuffer[17].getData();;
                ;break;
	case "R19":  RegBinary = regfileBuffer[18].getData();;
                 ;break;
	case "R20":  RegBinary = regfileBuffer[19].getData();;
				 ;break;
	case "R21":  RegBinary = regfileBuffer[20].getData();;
				;break;
	case "R22":  RegBinary = regfileBuffer[21].getData();;
				;break;
	case "R23":  RegBinary = regfileBuffer[22].getData();;
           		 ;break;
	case "R24":  RegBinary = regfileBuffer[23].getData();;
				;break;
	case "R25":  RegBinary = regfileBuffer[24].getData();;
				;break;
	case "R26":  RegBinary = regfileBuffer[25].getData();;
				 ;break;
	case "R27":  RegBinary = regfileBuffer[26].getData();;
				 ;break;
	case "R28":  RegBinary = regfileBuffer[27].getData();;
				 ;break;
	case "R29":  RegBinary = regfileBuffer[28].getData();;
     		;break;
	case "R30":  RegBinary = regfileBuffer[29].getData();
			;break;
	case "R31":  RegBinary = regfileBuffer[30].getData();;
				;break;

	}
	
	
	return RegBinary;
}
public static String convBinaryToReg(String address) {
	String RegName = "";
	switch(address) {
	case "00000" : RegName = "R0" ; 	break;
	case "00001":   RegName = "R1";
			    ;break;
	case "00010":   RegName = "R2";
				;break;
	case "00011":   RegName = "R3";
                ;break;
	case "00100":   RegName = "R4";
				;break;
	case "00101":   RegName = "R5";
				;break;
	case "00110":   RegName = "R6";
				;break;
	case "00111":   RegName = "R7";
				;break;
	case "01000":   RegName = "R8";
				;break;
	case "01001": 	 RegName = "R9";
				;break;
	case "01010":  RegName = "R10";
                ;break;
	case "01011":  RegName = "R11";
			     ;break;
	case "01100":  RegName = "R12";
                ;break;
	case "01101":  RegName = "R13";
				;break;
	case "01110":  RegName = "R14";
				;break;
	case "01111":  RegName = "R15";
                ;break;
	case "10000":  RegName = "R16";
                ;break;
	case "10001":  RegName = "R17";
				;break;
	case "10010":  RegName = "R18";
                ;break;
	case "10011":  RegName = "R19";
                ;break;
	case "10100":  RegName = "R20";
				;break;
	case "10101":  RegName = "R21";
				;break;
	case "10110":  RegName = "R22";
				;break;
	case "10111":  RegName = "R23";
           		;break;
	case "11000":  RegName = "R24";
				;break;
	case "11001":  RegName = "R25";
			    ;break;
	case "11010":  RegName = "R26";
				;break;
	case "11011":  RegName = "R27";
				;break;
	case "11100":  RegName = "R28";
				;break;
	case "11101":  RegName = "R29";
     			;break;
	case "11110":  RegName = "R30";
				;break;
	case "11111":  RegName = "R31";
				;break;
	}	
	
	return RegName;
}
public static Register[] getRegfileBuffer() {
	return regfileBuffer;
}
public static void setRegfileBuffer(Register[] regfileBuffer) {
	RegFile.regfileBuffer = regfileBuffer;
}
    

}
