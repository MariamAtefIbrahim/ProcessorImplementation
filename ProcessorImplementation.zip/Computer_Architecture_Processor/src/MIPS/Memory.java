package MIPS;

import java.io.BufferedReader;
import MIPS.RegFile;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import Instructions.ADD;
import Instructions.AND;
import Instructions.Instruction;
import Instructions.Instruction_Types;
import Instructions.JEQ;
import Instructions.JMP;
import Instructions.LSL;
import Instructions.LSR;
import Instructions.MOVI;
import Instructions.MOVM;
import Instructions.MOVR;
import Instructions.MUL;
import Instructions.SUB;
import Instructions.XORI;

public class Memory {
	
	  private static String[] MemoryBuffer ; 
	  private static int instCount ;

	  
	  public String[] getMemoryBuffer() {
		return MemoryBuffer;
	}

	public Memory() {
		  MemoryBuffer = new String[2048] ;
	  }
	  
	  
	  public static void loadInstructions() throws IOException {
			BufferedReader br = new BufferedReader(new FileReader("Z:\\java-2022-06\\Computer_Architecture_Processor\\src\\MIPS_TEST.txt"));
			String line = br.readLine();
			int i = 0;
			while (line!=null) {
				String[] content = line.split(" ");
				Instruction inst= null ;
				Instruction_Types inst_type = null;
				String memory_inst =""; 
				String binary_format ;
				
				switch(content[0]) {
				case "ADD" : inst = new ADD(); break;
				case "AND" : inst = new AND(); break;
				case "JEQ" : inst = new JEQ(); break;
				case "JMP" : inst = new JMP(); break;
				case "LSL" : inst = new LSL(); break;
				case "LSR" : inst = new LSR(); break;
				case "MOVI" : inst = new MOVI(); break;
				case "MOVM" : inst = new MOVM(); break;
				case "MOVR" : inst = new MOVR(); break;
				case "MUL" : inst = new MUL(); break;
				case "SUB" : inst = new SUB(); break;
				case "XORI" : inst = new XORI(); break;
				}
				
				switch(inst.getInst_type()) {
				case R_type : 
					String r1r = RegFile.convRegtoBinary(content[2]);
					String r2r = RegFile.convRegtoBinary(content[3]);
					String r3r = RegFile.convRegtoBinary(content[1]);
					
					if(inst.getOpcode() !="1000" && inst.getOpcode()!="1001") {
						
						memory_inst = inst.getOpcode() +r1r+r2r+r3r+"0000000000000";
					}
					else {
						int shamtInt = Integer.parseInt(content[3]);
						String shamt = Integer.toBinaryString(shamtInt);
						if(shamt.length()==32 && shamt.charAt(0)=='1' && shamtInt <0) {
							shamt = shamt.substring(19,32);
						}
						else {
							
						
						while(shamt.length()<13) {
							if(shamtInt >=0) {
								shamt = "0"+ shamt;	

							}
						
						}
						}
						memory_inst = inst.getOpcode() + r1r +"00000"+r3r+shamt;
					} ;break;
				case I_type : 	
					String r1i = RegFile.convRegtoBinary(content[2]);
					String r3i = RegFile.convRegtoBinary(content[1]);
				
					 if(inst.getOpcode() !="0011") {
						int imdInt = Integer.parseInt(content[3]);
						String imd = Integer.toBinaryString(imdInt);
						if(imd.length()==32 && imd.charAt(0)=='1' && imdInt <0) {
							imd = imd.substring(14,32);
						}
						else {
							
						
					
						while(imd.length()<18) {
							if(imdInt >=0) {
								imd = "0"+ imd;	

							}
						
						
						}
						}
						memory_inst = inst.getOpcode() + r1i+ r3i+ imd;
					}
					else {
						int imdInt = Integer.parseInt(content[2]);
						String imd = Integer.toBinaryString(imdInt);
						if(imd.length()==32 && imd.charAt(0)=='1'&& imdInt <0) {
							imd = imd.substring(14,32);
						}
						else {
							while(imd.length()<18) {
								if(imdInt >=0) {
									imd = "0"+ imd;	

								}
							
						}
					
						}
						memory_inst = inst.getOpcode() +r1i+"00000"+r3i+imd;

					};break;
				case J_type:
					int addressInt = Integer.parseInt(content[1]);
					String address = Integer.toBinaryString(addressInt);
					while(address.length()<28) {
						if(addressInt >=0) {
							address = "0"+ address;	

						}
						else {
							address = address.substring(4, 32);

						}
				
					}
					memory_inst = inst.getOpcode() + address;
					}
				MemoryBuffer[i]=memory_inst;
				instCount++;
				i++;
				if(i == 1024) {
					System.out.println("Instruction Memory is Full , Oops!");
					break;
				}
				
				
				
			
				
				line = br.readLine();
				
		}
			br.close();

			

		
  }

	public static int getInstCount() {
		return instCount;
	}

	public static void setInstCount(int instCount) {
		Memory.instCount = instCount;
	}

	public static void setMemoryBuffer(String[] memoryBuffer) {
		MemoryBuffer = memoryBuffer;
	}

}
