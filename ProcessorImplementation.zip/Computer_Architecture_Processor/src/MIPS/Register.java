package MIPS;
import java.util.*;
public class Register {
	private String name;
	public void setAddress(String address) {
		this.address = address;
	}
	private String address ;
	private int data ;
    public Register(String name) {
    	this.name = name ;
    }
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getData() {
		return data;
	}
	public void setData(int data) {
		this.data = data;
	}
	public String getAddress() {
		return address;
	}

	

}
